/**
 * @syntax undefined
 * @returns {undefined}
 */
var undefined;
