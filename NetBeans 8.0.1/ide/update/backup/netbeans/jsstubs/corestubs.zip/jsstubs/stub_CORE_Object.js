/**
 * @syntax new Object( [ value ] )
 * @param {String} 
 * @returns {Object}
 */
function Object( ) {
}
/**
 * @syntax isPrototypeOf(V)
 * @param {Object} V
 * @returns {Boolean}
 */
Object.prototype.isPrototypeOf = function(V) {};

/**
 * @syntax toLocaleString()
 * @returns {String}
 */
Object.prototype.toLocaleString = function() {};

/**
 * @syntax defineProperties(O,Properties)
 * @param {Object} O
 * @param {Object} Properties
 * @returns {undefined}
 * @static
 */
Object.defineProperties = function(O, Properties) {};

/**
 * @syntax keys(O)
 * @param {Object} O
 * @returns {Array}
 * @static
 */
Object.keys = function(O) {};

/**
 * @syntax isExtensible(O)
 * @param {Object} O
 * @returns {Boolean}
 * @static
 */
Object.isExtensible = function(O) {};

/**
 * @syntax isFrozen(O)
 * @param {Object} O
 * @returns {Boolean}
 * @static
 */
Object.isFrozen = function(O) {};

/**
 * @syntax create(O[,Properties])
 * @param {Object} O
 * @returns {Object}
 * @static
 */
Object.create = function(O) {};

/**
 * @syntax hasOwnProperty(V)
 * @param {String} V
 * @returns {Boolean}
 */
Object.prototype.hasOwnProperty = function(V) {};

/**
 * @syntax getOwnPropertyDescriptor(O,P)
 * @param {Object} O
 * @param {String} P
 * @returns {Object}
 * @static
 */
Object.getOwnPropertyDescriptor = function(O, P) {};

/**
 * @syntax isSealed(O)
 * @param {Object} O
 * @returns {Boolean}
 * @static
 */
Object.isSealed = function(O) {};

/**
 * @syntax getPrototypeOf(O)
 * @param {Object} O
 * @returns {Object}
 * @static
 */
Object.getPrototypeOf = function(O) {};

/**
 * @syntax seal(O)
 * @param {Object} O
 * @returns {Object}
 * @static
 */
Object.seal = function(O) {};

/**
 * @syntax propertyIsEnumerable(V)
 * @param {String} V
 * @returns {Boolean}
 */
Object.prototype.propertyIsEnumerable = function(V) {};

/**
 * @syntax freeze(O)
 * @param {Object} O
 * @returns {Object}
 * @static
 */
Object.freeze = function(O) {};

/**
 * @syntax getOwnPropertyNames(O)
 * @param {Object} O
 * @returns {Array}
 * @static
 */
Object.getOwnPropertyNames = function(O) {};

/**
 * @syntax preventExtensions(O)
 * @param {Object} O
 * @returns {Object}
 * @static
 */
Object.preventExtensions = function(O) {};

/**
 * @syntax toString()
 * @returns {String}
 */
Object.prototype.toString = function() {};

/**
 * @syntax valueOf()
 * @returns {Object}
 */
Object.prototype.valueOf = function() {};

/**
 * @syntax defineProperty(O,P,Attributes)
 * @param {Object} O
 * @param {String} P
 * @param {String} Attributes
 * @returns {Object}
 * @static
 */
Object.defineProperty = function(O, P, Attributes) {};

/**
 * @syntax constructor
 * @returns {Function}
 */
Object.prototype.constructor = new Function();

/**
 * @syntax prototype
 * @returns {Object}
 * @static
 */
Object.prototype;

