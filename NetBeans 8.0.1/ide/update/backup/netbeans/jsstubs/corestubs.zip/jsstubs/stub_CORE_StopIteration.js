/**
 * @returns {StopIteration} 
 */
var StopIteration = {
}
/**
 * Represents the StopIteration prototype object.
 * @syntax StopIteration.prototype
 * @static
 */
StopIteration.prototype;

