/**
 * @syntax isNaN(testValue)
 * @param {String} testValue
 * @returns {Boolean}
 */
function isNaN(testValue) {};
