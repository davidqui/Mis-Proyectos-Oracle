/**
 * @syntax new RangeError([message[, fileName[, lineNumber]]])
 * @param {String} 
 * @returns {Error}
 */
function RangeError() {
}
/**
 * @returns {String}
 */
RangeError.prototype.name = new String();

/**
 * @returns {Function}
 */
RangeError.prototype.constructor = new Function();

/**
 * @returns {Object}
 * @static
 */
RangeError.prototype;

