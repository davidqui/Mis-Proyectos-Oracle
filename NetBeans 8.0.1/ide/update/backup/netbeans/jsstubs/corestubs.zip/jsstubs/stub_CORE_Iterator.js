/**
 * @returns {Iterator} 
 */
var Iterator = {
}
/**
 * Represents the Iterator prototype object.
 * @syntax Iterator.prototype
 * @static
 */
Iterator.prototype;

