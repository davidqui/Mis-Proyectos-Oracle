/**
 * A DOMString is a sequence of 16-bit units.
 */
var DOMString = {
}
/**
 * Represents the DOMString prototype object.
 * @syntax DOMString.prototype
 * @static
 */
DOMString.prototype;

