/**
 * Script statements. See the SCRIPT element definition in HTML 4.01.
 */
var HTMLScriptElement = {
}
/**
 * Indicates that the user agent can defer processing of the script. See the defer attribute definition in HTML 4.01.
 * @syntax hTMLScriptElement.defer
 * @returns {boolean} 
 */
HTMLScriptElement.prototype.defer = new boolean();

/**
 * The script content of the element.
 * @syntax hTMLScriptElement.text
 * @returns {String} 
 */
HTMLScriptElement.prototype.text = new String();

/**
 * Reserved for future use.
 * @syntax hTMLScriptElement.event
 * @returns {String} 
 */
HTMLScriptElement.prototype.event = new String();

/**
 * Reserved for future use.
 * @syntax hTMLScriptElement.htmlFor
 * @returns {String} 
 */
HTMLScriptElement.prototype.htmlFor = new String();

/**
 * The character encoding of the linked resource. See the charset attribute definition in HTML 4.01.
 * @syntax hTMLScriptElement.charset
 * @returns {String} 
 */
HTMLScriptElement.prototype.charset = new String();

/**
 * URI [IETF RFC 2396] designating an external script. See the src attribute definition in HTML 4.01.
 * @syntax hTMLScriptElement.src
 * @returns {String} 
 */
HTMLScriptElement.prototype.src = new String();

/**
 * The content type of the script language. See the type attribute definition in HTML 4.01.
 * @syntax hTMLScriptElement.type
 * @returns {String} 
 */
HTMLScriptElement.prototype.type = new String();

/**
 * Represents the HTMLScriptElement prototype object.
 * @syntax HTMLScriptElement.prototype
 * @static
 */
HTMLScriptElement.prototype;

