/**
 * A DOMTimeStamp represents a number of milliseconds.
 */
var DOMTimeStamp = {
}
/**
 * Represents the DOMTimeStamp prototype object.
 * @syntax DOMTimeStamp.prototype
 * @static
 */
DOMTimeStamp.prototype;

