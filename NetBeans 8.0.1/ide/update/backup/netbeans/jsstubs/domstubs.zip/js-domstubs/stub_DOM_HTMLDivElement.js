/**
 * Generic block container. See the DIV element definition in HTML 4.01.
 */
var HTMLDivElement = {
}
/**
 * Horizontal text alignment. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLDivElement.align
 * @returns {String} 
 */
HTMLDivElement.prototype.align = new String();

/**
 * Represents the HTMLDivElement prototype object.
 * @syntax HTMLDivElement.prototype
 * @static
 */
HTMLDivElement.prototype;

