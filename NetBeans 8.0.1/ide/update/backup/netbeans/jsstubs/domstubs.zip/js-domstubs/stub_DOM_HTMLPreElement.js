/**
 * Preformatted text. See the PRE element definition in HTML 4.01.
 */
var HTMLPreElement = {
}
/**
 * Fixed width for content. See the width attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLPreElement.width
 * @returns {Number} 
 */
HTMLPreElement.prototype.width = new Number();

/**
 * Represents the HTMLPreElement prototype object.
 * @syntax HTMLPreElement.prototype
 * @static
 */
HTMLPreElement.prototype;

