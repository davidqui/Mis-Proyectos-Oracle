/**
 * The anchor element. See the A element definition in HTML 4.01.
 */
var HTMLAnchorElement = {
}
/**
 * A single character access key to give access to the form control. See the accesskey attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.accessKey
 * @returns {String} 
 */
HTMLAnchorElement.prototype.accessKey = new String();

/**
 * Reverse link type. See the rev attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.rev
 * @returns {String} 
 */
HTMLAnchorElement.prototype.rev = new String();

/**
 * Index that represents the element's position in the tabbing order. See the tabindex attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.tabIndex
 * @returns {Number} 
 */
HTMLAnchorElement.prototype.tabIndex = new Number();

/**
 * The character encoding of the linked resource. See the charset attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.charset
 * @returns {String} 
 */
HTMLAnchorElement.prototype.charset = new String();

/**
 * Removes keyboard focus from this element.
 * @syntax hTMLAnchorElement.blur()
 * @returns {undefined} 
 */
HTMLAnchorElement.prototype.blur = function() {};

/**
 * The shape of the active area. The coordinates are given by coords. See the shape attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.shape
 * @returns {String} 
 */
HTMLAnchorElement.prototype.shape = new String();

/**
 * Advisory content type. See the type attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.type
 * @returns {String} 
 */
HTMLAnchorElement.prototype.type = new String();

/**
 * Language code of the linked resource. See the hreflang attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.hreflang
 * @returns {String} 
 */
HTMLAnchorElement.prototype.hreflang = new String();

/**
 * Comma-separated list of lengths, defining an active region geometry. See also shape for the shape of the region. See the coords attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.coords
 * @returns {String} 
 */
HTMLAnchorElement.prototype.coords = new String();

/**
 * Anchor name. See the name attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.name
 * @returns {String} 
 */
HTMLAnchorElement.prototype.name = new String();

/**
 * Frame to render the resource in. See the target attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.target
 * @returns {String} 
 */
HTMLAnchorElement.prototype.target = new String();

/**
 * Gives keyboard focus to this element.
 * @syntax hTMLAnchorElement.focus()
 * @returns {undefined} 
 */
HTMLAnchorElement.prototype.focus = function() {};

/**
 * Forward link type. See the rel attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.rel
 * @returns {String} 
 */
HTMLAnchorElement.prototype.rel = new String();

/**
 * The absolute URI [IETF RFC 2396] of the linked resource. See the href attribute definition in HTML 4.01.
 * @syntax hTMLAnchorElement.href
 * @returns {String} 
 */
HTMLAnchorElement.prototype.href = new String();

/**
 * Represents the HTMLAnchorElement prototype object.
 * @syntax HTMLAnchorElement.prototype
 * @static
 */
HTMLAnchorElement.prototype;

