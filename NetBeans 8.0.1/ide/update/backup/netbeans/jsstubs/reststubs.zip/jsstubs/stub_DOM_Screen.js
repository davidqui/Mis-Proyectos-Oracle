/**
 */
var Screen = {
}
/**
 * @returns {Number}
 */
Screen.prototype.height = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.pixelDepth = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.width = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.availTop = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.left = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.colorDepth = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.availHeight = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.availLeft = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.top = new Number();

/**
 * @returns {Number}
 */
Screen.prototype.availWidth = new Number();

/**
 * Represents the Screen prototype object.
 * @syntax Screen.prototype
 * @static
 */
Screen.prototype;

